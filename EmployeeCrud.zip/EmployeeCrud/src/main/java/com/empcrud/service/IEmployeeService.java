package com.empcrud.service;

import com.empcrud.dto.EmpDeptResponse;

import java.util.List;

public interface IEmployeeService {
    List<EmpDeptResponse> getEmpAllDetails(int deptNo);
}
