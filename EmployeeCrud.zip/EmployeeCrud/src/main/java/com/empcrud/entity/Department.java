package com.empcrud.entity;

import javax.persistence.*;
import java.util.List;

@Entity
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int deptNo;

    @Column(name = "DepartmentName")
    private String deptName;

    @OneToMany(mappedBy = "deptNo") // @Column(name = "DeptName")
    private List<Employee> employee;

    public Department() {
        super();
    }

    public Department(int deptNo, String deptName, List<Employee> employee) {
        this.deptNo = deptNo;
        this.deptName = deptName;
        this.employee = employee;
    }

    public int getDeptNo() {
        return deptNo;
    }

    public void setDeptNo(int deptNo) {
        this.deptNo = deptNo;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public List<Employee> getEmployee() {
        return employee;
    }

    public void setEmployee(List<Employee> employee) {
        this.employee = employee;
    }
}