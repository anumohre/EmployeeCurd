package com.empcrud.entity;

import javax.persistence.*;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    @Column(name = "EmpNo")
    private int empNo;

    @Column(name = "EmpName")
    private String empName;

    @ManyToOne
    @JoinColumn(name = "DeptNo")
    private Department deptNo;

    public Employee() {
        super();
    }

    public Employee(int empNo, String empName, Department deptNo) {
        this.empNo = empNo;
        this.empName = empName;
        this.deptNo = deptNo;
    }

    public int getEmpNo() {
        return empNo;
    }

    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public Department getDeptNo() {
        return deptNo;
    }

    public void setDeptNo(Department deptNo) {
        this.deptNo = deptNo;
    }
}
