package com.empcrud.repository;

import com.empcrud.dto.EmpDeptResponse;
import com.empcrud.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface EmployeeRepo extends JpaRepository<Employee,Integer> {

    @Query("SELECT new com.empcrud.dto.EmpDeptResponse(e.empNo,e.empName,d.deptName) from Employee e JOIN e.deptNo d WHERE d.deptNo = :deptNo")
    List<EmpDeptResponse> getAllEmployee(int deptNo);

    //@Query("SELECT new com.empcrud.dto.EmpDeptResponse(e.empNo,e.empName,d.deptName) from Employee e JOIN e.deptNo d")

}
