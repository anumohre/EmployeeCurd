package com.empcrud.controller;


import com.empcrud.dto.EmpDeptResponse;
import com.empcrud.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeRestController {

    @Autowired
    private IEmployeeService employeeService;

    @GetMapping("/")
    public String index(){
        return "Welcome to Employee Panel ....Perform your Endpoints";
    }

    @GetMapping("/GetAllEmpDetails/{deptNo}")
    public List<?> getAllEmpDetails( @PathVariable int deptNo ){

        List<EmpDeptResponse> result = employeeService.getEmpAllDetails(deptNo);
        try{
            if(!result.isEmpty()){
                return result;
            }else{
                throw new RuntimeException("No data Found with Id "+deptNo);
            }
        }
        catch(RuntimeException e){
            String s = e.getLocalizedMessage();
            return Collections.singletonList(s);
        }
    }
}
